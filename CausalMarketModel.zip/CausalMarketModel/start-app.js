const { spawn } = require('child_process');
const path = require('path');

console.log('🚀 Starting CausalMMM Application...');

// Start backend server
const backend = spawn('npx', ['tsx', 'server/index.ts'], {
  stdio: 'inherit',
  env: { ...process.env, PORT: '3000' }
});

backend.on('error', (err) => {
  console.error('❌ Backend error:', err);
});

// Start frontend server after a delay
setTimeout(() => {
  const frontend = spawn('npx', ['vite', '--host', '0.0.0.0', '--port', '5173'], {
    cwd: path.join(__dirname, 'client'),
    stdio: 'inherit'
  });

  frontend.on('error', (err) => {
    console.error('❌ Frontend error:', err);
  });

  frontend.on('exit', (code) => {
    console.log(`Frontend exited with code ${code}`);
    process.exit(code);
  });
}, 3000);

backend.on('exit', (code) => {
  console.log(`Backend exited with code ${code}`);
  process.exit(code);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('🛑 Shutting down CausalMMM...');
  backend.kill('SIGTERM');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('🛑 Shutting down CausalMMM...');
  backend.kill('SIGTERM');
  process.exit(0);
});