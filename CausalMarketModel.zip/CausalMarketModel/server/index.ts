import express from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import { promisify } from 'util';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const execAsync = promisify(exec);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

const upload = multer({ storage });

// In-memory storage for models and results
const models = new Map();
const trainingResults = new Map();

// Routes
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  
  res.json({
    id: req.file.filename,
    originalName: req.file.originalname,
    size: req.file.size,
    path: req.file.path
  });
});

app.post('/api/analyze-data', async (req, res) => {
  try {
    const { fileId } = req.body;
    const filePath = path.join(__dirname, '../uploads', fileId);
    
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }

    // Run Python script to analyze data structure
    const pythonScript = path.join(__dirname, 'analyze_data.py');
    const { stdout, stderr } = await execAsync(`python ${pythonScript} "${filePath}"`);
    
    if (stderr) {
      console.error('Python error:', stderr);
      return res.status(500).json({ error: 'Data analysis failed' });
    }

    const analysis = JSON.parse(stdout);
    res.json(analysis);
  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({ error: 'Analysis failed' });
  }
});

app.post('/api/train-model', async (req, res) => {
  try {
    const { 
      fileId, 
      mediaVars, 
      controlVars, 
      regionVar,
      targetVar,
      trainingConfig 
    } = req.body;
    
    const modelId = `model_${Date.now()}`;
    const filePath = path.join(__dirname, '../uploads', fileId);
    
    // Initialize training status
    trainingResults.set(modelId, {
      status: 'running',
      progress: 0,
      startTime: new Date(),
      config: { mediaVars, controlVars, regionVar, targetVar, trainingConfig }
    });

    // Start training in background
    trainModelAsync(modelId, filePath, { mediaVars, controlVars, regionVar, targetVar, trainingConfig });
    
    res.json({ modelId, status: 'started' });
  } catch (error) {
    console.error('Training error:', error);
    res.status(500).json({ error: 'Training failed to start' });
  }
});

app.get('/api/training-status/:modelId', (req, res) => {
  const { modelId } = req.params;
  const result = trainingResults.get(modelId);
  
  if (!result) {
    return res.status(404).json({ error: 'Model not found' });
  }
  
  res.json(result);
});

app.get('/api/model-results/:modelId', (req, res) => {
  const { modelId } = req.params;
  const model = models.get(modelId);
  
  if (!model) {
    return res.status(404).json({ error: 'Model not found' });
  }
  
  res.json(model);
});

async function trainModelAsync(modelId: string, filePath: string, config: any) {
  try {
    // Update progress
    const updateProgress = (progress: number, status: string = 'running') => {
      const current = trainingResults.get(modelId);
      trainingResults.set(modelId, { ...current, progress, status });
    };

    updateProgress(10, 'preparing_data');
    
    // Run CausalMMM training
    const pythonScript = path.join(__dirname, 'causal_mmm_trainer.py');
    const configStr = JSON.stringify(config);
    
    updateProgress(30, 'training_model');
    
    const { stdout, stderr } = await execAsync(`python ${pythonScript} "${filePath}" '${configStr}'`);
    
    if (stderr) {
      console.error('Python training error:', stderr);
      updateProgress(0, 'failed');
      return;
    }

    updateProgress(80, 'generating_results');
    
    const results = JSON.parse(stdout);
    
    // Store model results
    models.set(modelId, {
      id: modelId,
      results,
      config,
      createdAt: new Date()
    });
    
    updateProgress(100, 'completed');
    
  } catch (error) {
    console.error('Training async error:', error);
    const current = trainingResults.get(modelId);
    trainingResults.set(modelId, { ...current, status: 'failed', error: error.message });
  }
}

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/dist/index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`CausalMMM server running on http://0.0.0.0:${PORT}`);
});