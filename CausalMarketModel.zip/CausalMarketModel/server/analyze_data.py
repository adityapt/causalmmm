#!/usr/bin/env python3
"""
Data Analysis Script for CausalMMM
Analyzes uploaded CSV files to identify column types and suggest variable assignments
"""

import sys
import pandas as pd
import numpy as np
import json
from pathlib import Path

def analyze_data(file_path):
    """Analyze CSV data and return column analysis"""
    try:
        # Read the CSV file
        df = pd.read_csv(file_path)
        
        # Basic info
        analysis = {
            'shape': df.shape,
            'columns': list(df.columns),
            'dtypes': df.dtypes.astype(str).to_dict(),
            'null_counts': df.isnull().sum().to_dict(),
            'summary_stats': {},
            'suggested_assignments': {
                'potential_media': [],
                'potential_control': [],
                'potential_region': [],
                'potential_target': []
            }
        }
        
        # Generate summary statistics for numeric columns
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            analysis['summary_stats'][col] = {
                'mean': float(df[col].mean()),
                'std': float(df[col].std()),
                'min': float(df[col].min()),
                'max': float(df[col].max()),
                'median': float(df[col].median())
            }
        
        # Suggest variable assignments based on column names and patterns
        for col in df.columns:
            col_lower = col.lower()
            
            # Media variables (spend, cost, impression, etc.)
            if any(keyword in col_lower for keyword in ['media', 'spend', 'cost', 'impression', 'click', 'tv', 'radio', 'digital', 'social', 'search', 'display']):
                analysis['suggested_assignments']['potential_media'].append(col)
            
            # Control variables (seasonality, events, etc.)
            elif any(keyword in col_lower for keyword in ['control', 'season', 'holiday', 'event', 'weather', 'economic', 'price', 'promo', 'discount']):
                analysis['suggested_assignments']['potential_control'].append(col)
            
            # Region variables
            elif any(keyword in col_lower for keyword in ['region', 'area', 'market', 'geo', 'location', 'city', 'state', 'country']):
                analysis['suggested_assignments']['potential_region'].append(col)
            
            # Target variables (sales, revenue, etc.)
            elif any(keyword in col_lower for keyword in ['sales', 'revenue', 'target', 'conversion', 'response', 'outcome']):
                analysis['suggested_assignments']['potential_target'].append(col)
        
        # If no suggestions found, use heuristics
        if not analysis['suggested_assignments']['potential_target']:
            # Last numeric column might be target
            if numeric_cols.tolist():
                analysis['suggested_assignments']['potential_target'].append(numeric_cols[-1])
        
        if not analysis['suggested_assignments']['potential_media']:
            # First few numeric columns might be media
            for col in numeric_cols[:min(5, len(numeric_cols))]:
                if col not in analysis['suggested_assignments']['potential_target']:
                    analysis['suggested_assignments']['potential_media'].append(col)
        
        # Sample data preview
        analysis['sample_data'] = df.head(5).to_dict('records')
        
        return analysis
        
    except Exception as e:
        return {'error': str(e)}

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(json.dumps({'error': 'Usage: python analyze_data.py <file_path>'}))
        sys.exit(1)
    
    file_path = sys.argv[1]
    result = analyze_data(file_path)
    print(json.dumps(result, indent=2))