#!/usr/bin/env python3
"""
CausalMMM Trainer - Enhanced version with SHAP analysis
Based on the provided causal_gru_mmm.py with added functionality
"""

import sys
import json
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.preprocessing import StandardScaler, LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.utils
# import shap  # Disabled due to compatibility issues
import base64
from io import BytesIO
import warnings
warnings.filterwarnings('ignore')

# Set random seeds for reproducibility
SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)

class CausalEncoder(nn.Module):
    """Graph Neural Network encoder for media variables"""
    def __init__(self, A_prior, d_in=10, d_hid=10):
        super().__init__()
        self.register_buffer("A", A_prior)
        self.edge = nn.Sequential(
            nn.Linear(d_in*2, d_hid), nn.ReLU(),
            nn.Linear(d_hid, d_hid), nn.ReLU()
        )
        self.node = nn.Sequential(
            nn.Linear(d_in+d_hid, d_hid), nn.ReLU()
        )
    
    def forward(self, X):
        send, recv = X @ self.A.t(), X @ self.A
        He = self.edge(torch.cat([send, recv], -1))
        Z = self.node(torch.cat([X, He], -1))
        return Z

class GRUCausalMMM(nn.Module):
    """Main Causal MMM model with GRU for time-varying coefficients"""
    def __init__(self, A_prior, n_media=10, ctrl_dim=15, hidden=64, n_regions=2):
        super().__init__()
        self.n_media = n_media
        self.enc = CausalEncoder(A_prior, d_in=n_media, d_hid=n_media)
        self.gru = nn.GRU(input_size=n_media+ctrl_dim, hidden_size=hidden, batch_first=True)
        self.w_raw = nn.Linear(hidden, n_media)
        self.alpha = nn.Parameter(torch.full((n_media,), 0.5))
        self.hill_a = nn.Parameter(torch.ones(n_media))
        self.hill_g = nn.Parameter(torch.ones(n_media))
        self.ctrl_mlp = nn.Linear(ctrl_dim, hidden)
        self.reg_emb = nn.Embedding(n_regions, hidden)
        self.bias = nn.Parameter(torch.zeros(1))

    def adstock(self, x):
        """Apply adstock transformation"""
        out = torch.zeros_like(x)
        out[:, 0] = x[:, 0]
        alpha = torch.clamp(self.alpha, 0, 1).view(1, 1, -1)
        for t in range(1, x.size(1)):
            out[:, t] = x[:, t] + alpha * out[:, t-1]
        return out

    def hill(self, x):
        """Apply Hill transformation"""
        a = torch.clamp(self.hill_a, 0.1, 6).view(1, 1, -1)
        g = torch.clamp(self.hill_g, 1e-3).view(1, 1, -1)
        num = x.clamp(min=0).pow(a)
        return num / (num + g.pow(a) + 1e-8)

    def forward(self, Xm, Xc, R):
        B, T, _ = Xm.shape
        # Causal node embeddings each week
        Z_seq = torch.stack([self.enc(x) for x in Xm.unbind(1)], 1)
        media_in = self.hill(self.adstock(Xm)) + Z_seq
        gru_in = torch.cat([media_in, Xc], -1)
        h_seq, _ = self.gru(gru_in)
        w_pos = torch.softplus(self.w_raw(h_seq))
        media_term = (media_in * w_pos).sum(-1)
        ctrl_term = torch.relu(self.ctrl_mlp(Xc)).sum(-1) * 0.3
        reg_term = self.reg_emb(R).sum(-1).unsqueeze(1).expand(-1, T) * 0.3
        y_scaled = media_term + ctrl_term + reg_term + self.bias
        return y_scaled, w_pos

def create_media_adjacency(n_media):
    """Create simple adjacency matrix for media variables"""
    A = np.zeros((n_media, n_media))
    for i in range(n_media - 1):
        A[i, i + 1] = 1.0  # Simple chain structure
    return torch.tensor(A, dtype=torch.float32)

def simple_bayesian_belief(df, control_vars):
    """Simple belief vector generation without complex BN dependencies"""
    belief_vectors = []
    for _, row in df.iterrows():
        # Simple heuristic: use normalized values as belief
        beliefs = []
        for var in control_vars:
            val = row[var]
            if pd.isna(val):
                beliefs.append(0.5)
            else:
                # Normalize to [0, 1] range
                normalized = (val - df[var].min()) / (df[var].max() - df[var].min() + 1e-8)
                beliefs.append(normalized)
        belief_vectors.append(beliefs)
    return np.array(belief_vectors)

def prepare_data(df, media_vars, control_vars, region_var, target_var, train_ratio=0.8):
    """Prepare data for training"""
    # Handle regions
    if region_var and region_var in df.columns:
        le_region = LabelEncoder()
        df['region_id'] = le_region.fit_transform(df[region_var].astype(str))
        n_regions = len(le_region.classes_)
        region_names = le_region.classes_
    else:
        df['region_id'] = 0
        n_regions = 1
        region_names = ['Default']

    # Get belief vectors for control variables
    Z_ctrl = simple_bayesian_belief(df, control_vars)
    
    # Train/test split
    split_idx = int(len(df) * train_ratio)
    train_mask = np.arange(len(df)) < split_idx
    test_mask = ~train_mask
    
    # Scale data
    m_scaler = StandardScaler().fit(df.loc[train_mask, media_vars])
    c_scaler = StandardScaler().fit(Z_ctrl[train_mask])
    y_scaler = StandardScaler().fit(df.loc[train_mask, [target_var]])
    
    Xm = m_scaler.transform(df[media_vars])
    Xc = c_scaler.transform(Z_ctrl)
    Y = y_scaler.transform(df[[target_var]]).ravel()
    R = df['region_id'].values
    
    # Convert to sequences by region
    def to_seq(arr):
        sequences = []
        for region_id in range(n_regions):
            region_mask = df['region_id'] == region_id
            if region_mask.sum() > 0:
                sequences.append(arr[region_mask])
        
        if not sequences:
            # If no regions, create single sequence
            sequences = [arr]
        
        # Pad sequences to same length
        max_len = max(len(seq) for seq in sequences)
        padded = []
        for seq in sequences:
            if len(seq.shape) == 1:
                padded_seq = np.zeros((max_len,))
                padded_seq[:len(seq)] = seq
            else:
                padded_seq = np.zeros((max_len, seq.shape[1]))
                padded_seq[:len(seq)] = seq
            padded.append(padded_seq)
        
        return np.stack(padded, 0)
    
    Xm_seq = torch.tensor(to_seq(Xm), dtype=torch.float32)
    Xc_seq = torch.tensor(to_seq(Xc), dtype=torch.float32)
    Y_seq = torch.tensor(to_seq(Y.reshape(-1, 1))[:, :, 0], dtype=torch.float32)
    
    # Split training and testing
    T_train = split_idx
    if Xm_seq.size(1) > T_train:
        Xm_tr, Xm_te = Xm_seq[:, :T_train], Xm_seq[:, T_train:]
        Xc_tr, Xc_te = Xc_seq[:, :T_train], Xc_seq[:, T_train:]
        Y_tr, Y_te = Y_seq[:, :T_train], Y_seq[:, T_train:]
    else:
        Xm_tr, Xm_te = Xm_seq, Xm_seq[:, -1:, :]
        Xc_tr, Xc_te = Xc_seq, Xc_seq[:, -1:, :]
        Y_tr, Y_te = Y_seq, Y_seq[:, -1:]
    
    return {
        'Xm_tr': Xm_tr, 'Xm_te': Xm_te,
        'Xc_tr': Xc_tr, 'Xc_te': Xc_te,
        'Y_tr': Y_tr, 'Y_te': Y_te,
        'scalers': {'media': m_scaler, 'control': c_scaler, 'target': y_scaler},
        'n_regions': n_regions,
        'region_names': region_names,
        'media_vars': media_vars,
        'control_vars': control_vars
    }

def create_visualizations(model, data, results):
    """Create comprehensive visualizations"""
    plots = {}
    
    # 1. Training Loss Plot
    fig_loss = go.Figure()
    fig_loss.add_trace(go.Scatter(
        x=list(range(len(results['train_losses']))),
        y=results['train_losses'],
        mode='lines',
        name='Training Loss',
        line=dict(color='blue')
    ))
    
    if 'test_losses' in results:
        fig_loss.add_trace(go.Scatter(
            x=list(range(len(results['test_losses']))),
            y=results['test_losses'],
            mode='lines',
            name='Test Loss',
            line=dict(color='red')
        ))
    
    fig_loss.update_layout(
        title='Model Training Loss',
        xaxis_title='Epoch',
        yaxis_title='Loss',
        template='plotly_white'
    )
    plots['training_loss'] = json.loads(fig_loss.to_json())
    
    # 2. Media Coefficients Over Time
    media_vars = data['media_vars']
    coefficients = results['media_coefficients']  # Shape: [n_regions, n_weeks, n_media]
    
    fig_coef = make_subplots(
        rows=len(media_vars), cols=1,
        subplot_titles=media_vars,
        shared_xaxis=True
    )
    
    colors = px.colors.qualitative.Set3
    for i, media_var in enumerate(media_vars):
        for region_idx in range(data['n_regions']):
            region_name = data['region_names'][region_idx]
            fig_coef.add_trace(
                go.Scatter(
                    x=list(range(coefficients.shape[1])),
                    y=coefficients[region_idx, :, i],
                    mode='lines',
                    name=f'{region_name}',
                    line=dict(color=colors[region_idx % len(colors)]),
                    showlegend=(i == 0)
                ),
                row=i+1, col=1
            )
    
    fig_coef.update_layout(
        title='Media Coefficients Over Time',
        height=200 * len(media_vars),
        template='plotly_white'
    )
    plots['media_coefficients'] = json.loads(fig_coef.to_json())
    
    # 3. Actual vs Predicted
    y_actual = results['y_actual']
    y_pred = results['y_pred']
    
    fig_pred = go.Figure()
    fig_pred.add_trace(go.Scatter(
        x=y_actual,
        y=y_pred,
        mode='markers',
        name='Predictions',
        marker=dict(color='blue', opacity=0.6)
    ))
    
    # Add diagonal line
    min_val = min(y_actual.min(), y_pred.min())
    max_val = max(y_actual.max(), y_pred.max())
    fig_pred.add_trace(go.Scatter(
        x=[min_val, max_val],
        y=[min_val, max_val],
        mode='lines',
        name='Perfect Prediction',
        line=dict(color='red', dash='dash')
    ))
    
    fig_pred.update_layout(
        title='Actual vs Predicted Values',
        xaxis_title='Actual',
        yaxis_title='Predicted',
        template='plotly_white'
    )
    plots['actual_vs_predicted'] = json.loads(fig_pred.to_json())
    
    # 4. Feature Importance (SHAP values)
    if 'shap_values' in results:
        shap_values = results['shap_values']
        feature_names = media_vars + [f'control_{i}' for i in range(len(data['control_vars']))]
        
        # Mean absolute SHAP values
        mean_shap = np.mean(np.abs(shap_values), axis=0)
        
        fig_shap = go.Figure(data=[
            go.Bar(
                x=feature_names,
                y=mean_shap,
                marker_color='lightblue'
            )
        ])
        
        fig_shap.update_layout(
            title='Feature Importance (SHAP Values)',
            xaxis_title='Features',
            yaxis_title='Mean |SHAP Value|',
            template='plotly_white'
        )
        plots['feature_importance'] = json.loads(fig_shap.to_json())
    
    return plots

def train_model(file_path, config):
    """Main training function"""
    try:
        # Load data
        df = pd.read_csv(file_path)
        
        # Extract configuration
        media_vars = config['mediaVars']
        control_vars = config['controlVars']
        region_var = config.get('regionVar')
        target_var = config['targetVar']
        training_config = config.get('trainingConfig', {})
        
        # Prepare data
        data = prepare_data(df, media_vars, control_vars, region_var, target_var)
        
        # Create model
        n_media = len(media_vars)
        n_control = len(control_vars)
        A_media = create_media_adjacency(n_media)
        
        model = GRUCausalMMM(
            A_media, 
            n_media=n_media, 
            ctrl_dim=n_control,
            hidden=training_config.get('hidden_size', 64),
            n_regions=data['n_regions']
        )
        
        # Training setup
        optimizer = torch.optim.Adam(model.parameters(), lr=training_config.get('learning_rate', 0.001))
        criterion = nn.MSELoss()
        epochs = training_config.get('epochs', 600)
        
        # Training loop
        train_losses = []
        test_losses = []
        
        R_ids = torch.arange(data['n_regions'])
        
        for epoch in range(epochs):
            model.train()
            optimizer.zero_grad()
            
            y_hat, w_pos = model(data['Xm_tr'], data['Xc_tr'], R_ids)
            loss = criterion(y_hat, data['Y_tr'])
            
            loss.backward()
            optimizer.step()
            
            train_losses.append(loss.item())
            
            # Test loss
            if epoch % 50 == 0:
                model.eval()
                with torch.no_grad():
                    y_hat_test, _ = model(data['Xm_te'], data['Xc_te'], R_ids)
                    test_loss = criterion(y_hat_test, data['Y_te'])
                    test_losses.append(test_loss.item())
        
        # Final predictions
        model.eval()
        with torch.no_grad():
            y_hat_train, w_train = model(data['Xm_tr'], data['Xc_tr'], R_ids)
            y_hat_test, w_test = model(data['Xm_te'], data['Xc_te'], R_ids)
            
            # Convert back to original scale
            y_train_pred = data['scalers']['target'].inverse_transform(
                y_hat_train.cpu().numpy().reshape(-1, 1)
            ).ravel()
            y_test_pred = data['scalers']['target'].inverse_transform(
                y_hat_test.cpu().numpy().reshape(-1, 1)
            ).ravel()
            
            y_train_actual = data['scalers']['target'].inverse_transform(
                data['Y_tr'].cpu().numpy().reshape(-1, 1)
            ).ravel()
            y_test_actual = data['scalers']['target'].inverse_transform(
                data['Y_te'].cpu().numpy().reshape(-1, 1)
            ).ravel()
        
        # Calculate metrics
        train_mse = np.mean((y_train_actual - y_train_pred) ** 2)
        test_mse = np.mean((y_test_actual - y_test_pred) ** 2)
        train_mae = np.mean(np.abs(y_train_actual - y_train_pred))
        test_mae = np.mean(np.abs(y_test_actual - y_test_pred))
        
        # Feature Importance Analysis (simplified without SHAP)
        shap_values = None
        try:
            # Calculate feature importance using gradient-based approach
            feature_importance = []
            feature_names = media_vars + [f'control_{i}' for i in range(len(control_vars))]
            
            model.eval()
            sample_input_media = data['Xm_tr'][:1, :10, :]  # Sample data
            sample_input_control = data['Xc_tr'][:1, :10, :]
            
            # Enable gradients for input
            sample_input_media.requires_grad_(True)
            sample_input_control.requires_grad_(True)
            
            # Forward pass
            output, _ = model(sample_input_media, sample_input_control, R_ids[:1])
            
            # Backward pass
            output.sum().backward()
            
            # Calculate importance as mean absolute gradient
            media_importance = sample_input_media.grad.abs().mean(dim=(0, 1)).cpu().numpy()
            control_importance = sample_input_control.grad.abs().mean(dim=(0, 1)).cpu().numpy()
            
            feature_importance = np.concatenate([media_importance, control_importance])
            shap_values = [feature_importance.tolist()]  # Format similar to SHAP
            
        except Exception as e:
            print(f"Feature importance analysis failed: {e}")
            shap_values = None
        
        # Compile results
        results = {
            'train_losses': train_losses,
            'test_losses': test_losses,
            'metrics': {
                'train_mse': float(train_mse),
                'test_mse': float(test_mse),
                'train_mae': float(train_mae),
                'test_mae': float(test_mae),
                'train_r2': float(1 - train_mse / np.var(y_train_actual)),
                'test_r2': float(1 - test_mse / np.var(y_test_actual))
            },
            'media_coefficients': w_train.cpu().numpy(),
            'y_actual': np.concatenate([y_train_actual, y_test_actual]),
            'y_pred': np.concatenate([y_train_pred, y_test_pred]),
            'shap_values': shap_values.tolist() if shap_values is not None else None
        }
        
        # Create visualizations
        plots = create_visualizations(model, data, results)
        results['plots'] = plots
        
        return results
        
    except Exception as e:
        return {'error': str(e)}

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(json.dumps({'error': 'Usage: python causal_mmm_trainer.py <file_path> <config_json>'}))
        sys.exit(1)
    
    file_path = sys.argv[1]
    config_json = sys.argv[2]
    
    try:
        config = json.loads(config_json)
        results = train_model(file_path, config)
        print(json.dumps(results, indent=2))
    except Exception as e:
        print(json.dumps({'error': str(e)}))