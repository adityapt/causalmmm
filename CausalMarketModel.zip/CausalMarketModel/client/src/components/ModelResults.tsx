import React, { useState } from 'react'
import { RotateCcw, Download, TrendingUp, BarChart3, Activity } from 'lucide-react'
import Plot from 'react-plotly.js'

interface ModelResultsProps {
  modelId: string | null
  results: any
  onStartNew: () => void
}

function ModelResults({ modelId, results, onStartNew }: ModelResultsProps) {
  const [activeTab, setActiveTab] = useState('overview')

  if (!results) {
    return (
      <div className="card">
        <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '16px' }}>
          Loading Results...
        </h2>
        <div className="progress">
          <div className="progress-bar" style={{ width: '100%', animation: 'pulse 2s infinite' }}></div>
        </div>
      </div>
    )
  }

  const tabs = [
    { id: 'overview', label: 'Overview', icon: TrendingUp },
    { id: 'training', label: 'Training Performance', icon: Activity },
    { id: 'coefficients', label: 'Media Coefficients', icon: BarChart3 },
    { id: 'shap', label: 'SHAP Analysis', icon: BarChart3 }
  ]

  const TabButton = ({ tab, active, onClick }: any) => (
    <button
      className={`tab-button ${active ? 'active' : ''}`}
      onClick={onClick}
      style={{
        padding: '12px 20px',
        border: 'none',
        borderBottom: active ? '2px solid #3b82f6' : '2px solid transparent',
        background: 'none',
        cursor: 'pointer',
        fontSize: '14px',
        fontWeight: '500',
        color: active ? '#3b82f6' : '#6b7280',
        display: 'flex',
        alignItems: 'center',
        gap: '8px'
      }}
    >
      <tab.icon size={16} />
      {tab.label}
    </button>
  )

  return (
    <div>
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0' }}>
            Model Results
          </h2>
          <button className="btn btn-secondary" onClick={onStartNew}>
            <RotateCcw size={16} style={{ marginRight: '8px' }} />
            Start New Analysis
          </button>
        </div>

        <div className="alert alert-success">
          Model training completed successfully! Model ID: {modelId}
        </div>
      </div>

      {/* Tabs */}
      <div className="card" style={{ padding: '0' }}>
        <div style={{ 
          display: 'flex', 
          borderBottom: '1px solid #e5e7eb',
          overflowX: 'auto'
        }}>
          {tabs.map(tab => (
            <TabButton
              key={tab.id}
              tab={tab}
              active={activeTab === tab.id}
              onClick={() => setActiveTab(tab.id)}
            />
          ))}
        </div>

        <div style={{ padding: '24px' }}>
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div>
              <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
                Model Performance Overview
              </h3>

              {results.results?.metrics && (
                <div className="grid grid-2">
                  <div className="card" style={{ margin: '0', marginRight: '12px' }}>
                    <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
                      Training Metrics
                    </h4>
                    <div style={{ marginBottom: '8px' }}>
                      <strong>MSE:</strong> {results.results.metrics.train_mse.toFixed(4)}
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                      <strong>MAE:</strong> {results.results.metrics.train_mae.toFixed(4)}
                    </div>
                    <div>
                      <strong>R²:</strong> {results.results.metrics.train_r2.toFixed(4)}
                    </div>
                  </div>

                  <div className="card" style={{ margin: '0', marginLeft: '12px' }}>
                    <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
                      Test Metrics
                    </h4>
                    <div style={{ marginBottom: '8px' }}>
                      <strong>MSE:</strong> {results.results.metrics.test_mse.toFixed(4)}
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                      <strong>MAE:</strong> {results.results.metrics.test_mae.toFixed(4)}
                    </div>
                    <div>
                      <strong>R²:</strong> {results.results.metrics.test_r2.toFixed(4)}
                    </div>
                  </div>
                </div>
              )}

              {results.results?.plots?.actual_vs_predicted && (
                <div style={{ marginTop: '24px' }}>
                  <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
                    Actual vs Predicted Values
                  </h4>
                  <Plot
                    data={results.results.plots.actual_vs_predicted.data}
                    layout={results.results.plots.actual_vs_predicted.layout}
                    config={{ responsive: true }}
                    style={{ width: '100%', height: '400px' }}
                  />
                </div>
              )}
            </div>
          )}

          {/* Training Performance Tab */}
          {activeTab === 'training' && (
            <div>
              <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
                Training Performance
              </h3>

              {results.results?.plots?.training_loss && (
                <div>
                  <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
                    Training Loss Curve
                  </h4>
                  <Plot
                    data={results.results.plots.training_loss.data}
                    layout={results.results.plots.training_loss.layout}
                    config={{ responsive: true }}
                    style={{ width: '100%', height: '400px' }}
                  />
                </div>
              )}

              <div style={{ marginTop: '24px' }}>
                <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
                  Training Summary
                </h4>
                <div className="grid grid-3">
                  <div>
                    <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#3b82f6' }}>
                      {results.config?.trainingConfig?.epochs || 600}
                    </div>
                    <div style={{ fontSize: '14px', color: '#6b7280' }}>
                      Total Epochs
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#16a34a' }}>
                      {results.config?.mediaVars?.length || 0}
                    </div>
                    <div style={{ fontSize: '14px', color: '#6b7280' }}>
                      Media Variables
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#dc2626' }}>
                      {results.config?.controlVars?.length || 0}
                    </div>
                    <div style={{ fontSize: '14px', color: '#6b7280' }}>
                      Control Variables
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Media Coefficients Tab */}
          {activeTab === 'coefficients' && (
            <div>
              <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
                Media Coefficients Over Time
              </h3>

              <p style={{ color: '#6b7280', marginBottom: '24px' }}>
                These coefficients represent the time-varying impact of each media channel. 
                Higher values indicate stronger influence on the target variable.
              </p>

              {results.results?.plots?.media_coefficients && (
                <Plot
                  data={results.results.plots.media_coefficients.data}
                  layout={results.results.plots.media_coefficients.layout}
                  config={{ responsive: true }}
                  style={{ width: '100%', height: '600px' }}
                />
              )}

              <div style={{ marginTop: '24px' }}>
                <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
                  Coefficient Interpretation
                </h4>
                <ul style={{ color: '#6b7280', lineHeight: '1.6', paddingLeft: '20px' }}>
                  <li>Coefficients show the marginal impact of each media channel over time</li>
                  <li>Values are automatically constrained to be positive (media can't decrease sales)</li>
                  <li>Temporal variations capture seasonality and changing market dynamics</li>
                  <li>Cross-media effects are captured through the graph neural network encoder</li>
                </ul>
              </div>
            </div>
          )}

          {/* SHAP Analysis Tab */}
          {activeTab === 'shap' && (
            <div>
              <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
                SHAP Feature Importance Analysis
              </h3>

              <p style={{ color: '#6b7280', marginBottom: '24px' }}>
                SHAP (SHapley Additive exPlanations) values show the contribution of each feature 
                to individual predictions, providing interpretable machine learning insights.
              </p>

              {results.results?.plots?.feature_importance ? (
                <div>
                  <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
                    Mean Feature Importance
                  </h4>
                  <Plot
                    data={results.results.plots.feature_importance.data}
                    layout={results.results.plots.feature_importance.layout}
                    config={{ responsive: true }}
                    style={{ width: '100%', height: '400px' }}
                  />
                </div>
              ) : (
                <div className="alert alert-info">
                  SHAP analysis was not completed for this model. This can happen with complex models 
                  or when computational resources are limited.
                </div>
              )}

              <div style={{ marginTop: '24px' }}>
                <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
                  Understanding SHAP Values
                </h4>
                <ul style={{ color: '#6b7280', lineHeight: '1.6', paddingLeft: '20px' }}>
                  <li><strong>Positive SHAP values:</strong> Feature increases the prediction</li>
                  <li><strong>Negative SHAP values:</strong> Feature decreases the prediction</li>
                  <li><strong>Magnitude:</strong> Larger absolute values indicate stronger influence</li>
                  <li><strong>Additivity:</strong> SHAP values sum to the difference between prediction and baseline</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Export Options */}
      <div className="card">
        <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
          Export Results
        </h3>

        <div className="grid grid-2">
          <button className="btn btn-secondary">
            <Download size={16} style={{ marginRight: '8px' }} />
            Download Plots as PNG
          </button>
          <button className="btn btn-secondary">
            <Download size={16} style={{ marginRight: '8px' }} />
            Export Model Summary
          </button>
        </div>
      </div>
    </div>
  )
}

export default ModelResults