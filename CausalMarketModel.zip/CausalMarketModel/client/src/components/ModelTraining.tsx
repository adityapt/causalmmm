import React, { useState, useEffect } from 'react'
import { ArrowLeft, Play, Clock, CheckCircle, AlertCircle } from 'lucide-react'

interface ModelTrainingProps {
  fileData: any
  modelConfig: any
  onTrainingComplete: (modelId: string, results: any) => void
  onBack: () => void
}

function ModelTraining({ fileData, modelConfig, onTrainingComplete, onBack }: ModelTrainingProps) {
  const [training, setTraining] = useState(false)
  const [modelId, setModelId] = useState<string | null>(null)
  const [status, setStatus] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let interval: NodeJS.Timeout
    
    if (modelId && training) {
      interval = setInterval(async () => {
        try {
          const response = await fetch(`/api/training-status/${modelId}`)
          if (response.ok) {
            const statusData = await response.json()
            setStatus(statusData)
            
            if (statusData.status === 'completed') {
              setTraining(false)
              // Fetch final results
              const resultsResponse = await fetch(`/api/model-results/${modelId}`)
              if (resultsResponse.ok) {
                const results = await resultsResponse.json()
                onTrainingComplete(modelId, results)
              }
            } else if (statusData.status === 'failed') {
              setTraining(false)
              setError(statusData.error || 'Training failed')
            }
          }
        } catch (err) {
          console.error('Status check failed:', err)
        }
      }, 2000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [modelId, training])

  const startTraining = async () => {
    setTraining(true)
    setError(null)
    
    try {
      const response = await fetch('/api/train-model', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileId: fileData.id,
          ...modelConfig
        })
      })

      if (!response.ok) {
        throw new Error('Failed to start training')
      }

      const data = await response.json()
      setModelId(data.modelId)
    } catch (err) {
      setTraining(false)
      setError('Failed to start training. Please try again.')
    }
  }

  const getStatusColor = () => {
    if (!status) return '#6b7280'
    switch (status.status) {
      case 'running':
      case 'preparing_data':
      case 'training_model':
      case 'generating_results':
        return '#3b82f6'
      case 'completed':
        return '#16a34a'
      case 'failed':
        return '#dc2626'
      default:
        return '#6b7280'
    }
  }

  const getStatusText = () => {
    if (!status) return 'Initializing...'
    switch (status.status) {
      case 'preparing_data':
        return 'Preparing data and creating Bayesian networks...'
      case 'training_model':
        return 'Training Causal MMM with GRU and Graph Neural Networks...'
      case 'generating_results':
        return 'Generating SHAP analysis and visualizations...'
      case 'completed':
        return 'Training completed successfully!'
      case 'failed':
        return 'Training failed'
      default:
        return 'Running...'
    }
  }

  return (
    <div>
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
          <button className="btn btn-secondary" onClick={onBack} style={{ marginRight: '16px' }}>
            <ArrowLeft size={16} />
          </button>
          <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0' }}>
            Model Training
          </h2>
        </div>

        <div className="alert alert-info">
          <strong>Configuration:</strong> {modelConfig.mediaVars.length} media variables, {modelConfig.controlVars.length} control variables
        </div>
      </div>

      {/* Training Configuration Summary */}
      <div className="card">
        <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
          Training Configuration
        </h3>

        <div className="grid grid-2">
          <div>
            <div style={{ marginBottom: '12px' }}>
              <strong>Media Variables ({modelConfig.mediaVars.length}):</strong>
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {modelConfig.mediaVars.join(', ')}
              </div>
            </div>

            <div style={{ marginBottom: '12px' }}>
              <strong>Control Variables ({modelConfig.controlVars.length}):</strong>
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {modelConfig.controlVars.join(', ')}
              </div>
            </div>

            <div style={{ marginBottom: '12px' }}>
              <strong>Target Variable:</strong>
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {modelConfig.targetVar}
              </div>
            </div>
          </div>

          <div>
            <div style={{ marginBottom: '12px' }}>
              <strong>Epochs:</strong>
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {modelConfig.trainingConfig.epochs}
              </div>
            </div>

            <div style={{ marginBottom: '12px' }}>
              <strong>Learning Rate:</strong>
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {modelConfig.trainingConfig.learning_rate}
              </div>
            </div>

            <div style={{ marginBottom: '12px' }}>
              <strong>Hidden Size:</strong>
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {modelConfig.trainingConfig.hidden_size}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Training Process */}
      <div className="card">
        <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
          Training Process
        </h3>

        <div style={{ marginBottom: '24px' }}>
          <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
            Model Architecture:
          </h4>
          <ul style={{ color: '#6b7280', lineHeight: '1.6', paddingLeft: '20px' }}>
            <li><strong>Causal Encoder:</strong> Graph Neural Network for media variable relationships</li>
            <li><strong>Bayesian Networks:</strong> Control variable belief vector generation</li>
            <li><strong>GRU Model:</strong> Time-varying coefficients β_j(t) for each media channel</li>
            <li><strong>Adstock & Hill Transformations:</strong> Marketing saturation and carryover effects</li>
            <li><strong>SHAP Analysis:</strong> Feature importance and contribution analysis</li>
          </ul>
        </div>

        {!training && !status && (
          <button className="btn" onClick={startTraining}>
            <Play size={16} style={{ marginRight: '8px' }} />
            Start Training
          </button>
        )}

        {error && (
          <div className="alert alert-error">
            <AlertCircle size={16} style={{ marginRight: '8px' }} />
            {error}
          </div>
        )}

        {training && (
          <div>
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              marginBottom: '16px',
              color: getStatusColor()
            }}>
              {status?.status === 'completed' ? (
                <CheckCircle size={20} style={{ marginRight: '8px' }} />
              ) : status?.status === 'failed' ? (
                <AlertCircle size={20} style={{ marginRight: '8px' }} />
              ) : (
                <Clock size={20} style={{ marginRight: '8px' }} />
              )}
              <span style={{ fontSize: '16px', fontWeight: '500' }}>
                {getStatusText()}
              </span>
            </div>

            <div className="progress" style={{ marginBottom: '16px' }}>
              <div 
                className="progress-bar" 
                style={{ 
                  width: `${status?.progress || 0}%`,
                  backgroundColor: getStatusColor()
                }}
              />
            </div>

            <div style={{ fontSize: '14px', color: '#6b7280' }}>
              Progress: {status?.progress || 0}%
            </div>

            {status?.startTime && (
              <div style={{ fontSize: '14px', color: '#6b7280', marginTop: '8px' }}>
                Started: {new Date(status.startTime).toLocaleTimeString()}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Training Details */}
      <div className="card">
        <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
          What Happens During Training
        </h3>

        <div className="grid grid-2">
          <div>
            <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
              Data Preparation:
            </h4>
            <ul style={{ color: '#6b7280', lineHeight: '1.6', paddingLeft: '20px' }}>
              <li>Bayesian Network structure learning on control variables</li>
              <li>Media adjacency matrix creation for graph encoder</li>
              <li>Data scaling and sequence generation by region</li>
              <li>Train/test split based on temporal order</li>
            </ul>
          </div>

          <div>
            <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
              Model Training:
            </h4>
            <ul style={{ color: '#6b7280', lineHeight: '1.6', paddingLeft: '20px' }}>
              <li>GRU learns time-varying media coefficients</li>
              <li>Graph encoder captures media variable dependencies</li>
              <li>Adstock and Hill transformations model saturation</li>
              <li>SHAP analysis for feature importance</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ModelTraining