import React, { useState } from 'react'
import { Upload, File } from 'lucide-react'

interface DataUploadProps {
  onFileUploaded: (fileData: any) => void
}

function DataUpload({ onFileUploaded }: DataUploadProps) {
  const [dragActive, setDragActive] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      uploadFile(e.dataTransfer.files[0])
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      uploadFile(e.target.files[0])
    }
  }

  const uploadFile = async (file: File) => {
    if (!file.name.endsWith('.csv')) {
      setError('Please upload a CSV file')
      return
    }

    setUploading(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append('file', file)

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      })

      if (!response.ok) {
        throw new Error('Upload failed')
      }

      const fileData = await response.json()
      onFileUploaded(fileData)
    } catch (err) {
      setError('Failed to upload file. Please try again.')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="card">
      <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '16px' }}>
        Upload Your Data
      </h2>
      
      <p style={{ color: '#6b7280', marginBottom: '24px' }}>
        Upload a CSV file containing your marketing data. The file should include media spend data, 
        control variables (seasonality, events, etc.), region information, and your target variable (sales, conversions, etc.).
      </p>

      {error && (
        <div className="alert alert-error">
          {error}
        </div>
      )}

      <div
        className={`upload-area ${dragActive ? 'drag-active' : ''}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        style={{
          border: `2px dashed ${dragActive ? '#3b82f6' : '#d1d5db'}`,
          borderRadius: '8px',
          padding: '40px',
          textAlign: 'center',
          backgroundColor: dragActive ? '#eff6ff' : '#f9fafb',
          cursor: 'pointer',
          transition: 'all 0.2s'
        }}
      >
        {uploading ? (
          <div>
            <div style={{ marginBottom: '16px' }}>
              <div className="progress">
                <div className="progress-bar" style={{ width: '100%', animation: 'pulse 2s infinite' }}></div>
              </div>
            </div>
            <p>Uploading file...</p>
          </div>
        ) : (
          <>
            <Upload size={48} style={{ color: '#6b7280', margin: '0 auto 16px' }} />
            <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '8px' }}>
              Drop your CSV file here
            </h3>
            <p style={{ color: '#6b7280', marginBottom: '16px' }}>
              or click to browse
            </p>
            <input
              type="file"
              accept=".csv"
              onChange={handleFileSelect}
              style={{ display: 'none' }}
              id="file-upload"
            />
            <label htmlFor="file-upload" className="btn">
              Choose File
            </label>
          </>
        )}
      </div>

      <div style={{ marginTop: '24px' }}>
        <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
          Data Requirements:
        </h4>
        <ul style={{ color: '#6b7280', lineHeight: '1.6' }}>
          <li>CSV format with column headers</li>
          <li>Media variables: TV spend, Digital spend, Social media spend, etc.</li>
          <li>Control variables: Seasonality indicators, holidays, economic factors, etc.</li>
          <li>Region variable: Geographic region, market, or similar</li>
          <li>Target variable: Sales, conversions, revenue, or other KPI</li>
          <li>Time dimension: Weekly or daily data recommended</li>
        </ul>
      </div>
    </div>
  )
}

export default DataUpload