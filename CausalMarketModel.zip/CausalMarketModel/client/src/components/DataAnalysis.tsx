import React, { useState, useEffect } from 'react'
import { ArrowLeft, CheckCircle, AlertCircle } from 'lucide-react'

interface DataAnalysisProps {
  fileData: any
  onAnalysisComplete: (analysisData: any, modelConfig: any) => void
  onBack: () => void
}

function DataAnalysis({ fileData, onAnalysisComplete, onBack }: DataAnalysisProps) {
  const [analysisData, setAnalysisData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  
  // Variable assignments
  const [mediaVars, setMediaVars] = useState<string[]>([])
  const [controlVars, setControlVars] = useState<string[]>([])
  const [regionVar, setRegionVar] = useState<string>('')
  const [targetVar, setTargetVar] = useState<string>('')
  
  // Training configuration
  const [trainingConfig, setTrainingConfig] = useState({
    epochs: 600,
    learning_rate: 0.001,
    hidden_size: 64,
    train_test_ratio: 0.8
  })

  useEffect(() => {
    analyzeData()
  }, [])

  const analyzeData = async () => {
    try {
      const response = await fetch('/api/analyze-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileId: fileData.id })
      })

      if (!response.ok) {
        throw new Error('Analysis failed')
      }

      const data = await response.json()
      setAnalysisData(data)
      
      // Set initial suggestions
      setMediaVars(data.suggested_assignments?.potential_media || [])
      setControlVars(data.suggested_assignments?.potential_control || [])
      setRegionVar(data.suggested_assignments?.potential_region?.[0] || '')
      setTargetVar(data.suggested_assignments?.potential_target?.[0] || '')
      
    } catch (err) {
      setError('Failed to analyze data. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const toggleVariable = (varName: string, category: 'media' | 'control') => {
    if (category === 'media') {
      if (mediaVars.includes(varName)) {
        setMediaVars(prev => prev.filter(v => v !== varName))
      } else {
        setMediaVars(prev => [...prev, varName])
        // Remove from control if it was there
        setControlVars(prev => prev.filter(v => v !== varName))
      }
    } else {
      if (controlVars.includes(varName)) {
        setControlVars(prev => prev.filter(v => v !== varName))
      } else {
        setControlVars(prev => [...prev, varName])
        // Remove from media if it was there
        setMediaVars(prev => prev.filter(v => v !== varName))
      }
    }
  }

  const canProceed = () => {
    return mediaVars.length > 0 && controlVars.length > 0 && targetVar
  }

  const handleProceed = () => {
    const modelConfig = {
      mediaVars,
      controlVars,
      regionVar: regionVar || null,
      targetVar,
      trainingConfig
    }
    onAnalysisComplete(analysisData, modelConfig)
  }

  if (loading) {
    return (
      <div className="card">
        <h2 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '16px' }}>
          Analyzing Data...
        </h2>
        <div className="progress">
          <div className="progress-bar" style={{ width: '100%', animation: 'pulse 2s infinite' }}></div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="card">
        <div className="alert alert-error">
          {error}
        </div>
        <button className="btn btn-secondary" onClick={onBack}>
          <ArrowLeft size={16} style={{ marginRight: '8px' }} />
          Back to Upload
        </button>
      </div>
    )
  }

  return (
    <div>
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '16px' }}>
          <button className="btn btn-secondary" onClick={onBack} style={{ marginRight: '16px' }}>
            <ArrowLeft size={16} />
          </button>
          <h2 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0' }}>
            Data Analysis & Variable Assignment
          </h2>
        </div>

        <div className="alert alert-info">
          <strong>File:</strong> {fileData.originalName} ({analysisData.shape[0]} rows, {analysisData.shape[1]} columns)
        </div>
      </div>

      {/* Variable Assignment */}
      <div className="card">
        <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
          Variable Assignment
        </h3>
        
        <p style={{ color: '#6b7280', marginBottom: '24px' }}>
          Click on variables to assign them to the appropriate categories. The model will use these assignments 
          to understand your data structure.
        </p>

        <div className="grid grid-2">
          <div>
            <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
              Media Variables ({mediaVars.length} selected)
            </h4>
            <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '12px' }}>
              Marketing channels, spend data, impressions, etc.
            </p>
            <div style={{ marginBottom: '24px' }}>
              {analysisData.columns.map((col: string) => (
                <span
                  key={col}
                  className={`tag ${mediaVars.includes(col) ? 'tag-selected' : ''}`}
                  onClick={() => toggleVariable(col, 'media')}
                  style={{ cursor: 'pointer' }}
                >
                  {col}
                </span>
              ))}
            </div>
          </div>

          <div>
            <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
              Control Variables ({controlVars.length} selected)
            </h4>
            <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '12px' }}>
              Seasonality, holidays, economic factors, etc.
            </p>
            <div style={{ marginBottom: '24px' }}>
              {analysisData.columns.map((col: string) => (
                <span
                  key={col}
                  className={`tag ${controlVars.includes(col) ? 'tag-selected' : ''}`}
                  onClick={() => toggleVariable(col, 'control')}
                  style={{ cursor: 'pointer' }}
                >
                  {col}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-2">
          <div>
            <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
              Region Variable
            </h4>
            <select
              className="select"
              value={regionVar}
              onChange={(e) => setRegionVar(e.target.value)}
            >
              <option value="">None (optional)</option>
              {analysisData.columns.map((col: string) => (
                <option key={col} value={col}>{col}</option>
              ))}
            </select>
          </div>

          <div>
            <h4 style={{ fontSize: '16px', fontWeight: '600', marginBottom: '12px' }}>
              Target Variable *
            </h4>
            <select
              className="select"
              value={targetVar}
              onChange={(e) => setTargetVar(e.target.value)}
            >
              <option value="">Select target variable</option>
              {analysisData.columns.map((col: string) => (
                <option key={col} value={col}>{col}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Training Configuration */}
      <div className="card">
        <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
          Training Configuration
        </h3>

        <div className="grid grid-2">
          <div>
            <label style={{ display: 'block', fontWeight: '500', marginBottom: '8px' }}>
              Number of Epochs
            </label>
            <input
              type="number"
              className="input"
              value={trainingConfig.epochs}
              onChange={(e) => setTrainingConfig(prev => ({ 
                ...prev, 
                epochs: parseInt(e.target.value) || 600 
              }))}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontWeight: '500', marginBottom: '8px' }}>
              Learning Rate
            </label>
            <input
              type="number"
              step="0.0001"
              className="input"
              value={trainingConfig.learning_rate}
              onChange={(e) => setTrainingConfig(prev => ({ 
                ...prev, 
                learning_rate: parseFloat(e.target.value) || 0.001 
              }))}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontWeight: '500', marginBottom: '8px' }}>
              Hidden Size
            </label>
            <input
              type="number"
              className="input"
              value={trainingConfig.hidden_size}
              onChange={(e) => setTrainingConfig(prev => ({ 
                ...prev, 
                hidden_size: parseInt(e.target.value) || 64 
              }))}
            />
          </div>

          <div>
            <label style={{ display: 'block', fontWeight: '500', marginBottom: '8px' }}>
              Train/Test Ratio
            </label>
            <input
              type="number"
              step="0.1"
              min="0.5"
              max="0.9"
              className="input"
              value={trainingConfig.train_test_ratio}
              onChange={(e) => setTrainingConfig(prev => ({ 
                ...prev, 
                train_test_ratio: parseFloat(e.target.value) || 0.8 
              }))}
            />
          </div>
        </div>
      </div>

      {/* Summary & Proceed */}
      <div className="card">
        <h3 style={{ fontSize: '20px', fontWeight: 'bold', marginBottom: '16px' }}>
          Configuration Summary
        </h3>

        <div className="grid grid-2">
          <div>
            <div style={{ marginBottom: '16px' }}>
              <strong>Media Variables:</strong> {mediaVars.length}
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {mediaVars.join(', ') || 'None selected'}
              </div>
            </div>

            <div style={{ marginBottom: '16px' }}>
              <strong>Control Variables:</strong> {controlVars.length}
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {controlVars.join(', ') || 'None selected'}
              </div>
            </div>
          </div>

          <div>
            <div style={{ marginBottom: '16px' }}>
              <strong>Region Variable:</strong>
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {regionVar || 'None (will use single region)'}
              </div>
            </div>

            <div style={{ marginBottom: '16px' }}>
              <strong>Target Variable:</strong>
              <div style={{ fontSize: '14px', color: '#6b7280' }}>
                {targetVar || 'Not selected'}
              </div>
            </div>
          </div>
        </div>

        {canProceed() ? (
          <div className="alert alert-success">
            <CheckCircle size={16} style={{ marginRight: '8px' }} />
            Configuration is complete. Ready to train the model!
          </div>
        ) : (
          <div className="alert alert-error">
            <AlertCircle size={16} style={{ marginRight: '8px' }} />
            Please select at least one media variable, one control variable, and a target variable.
          </div>
        )}

        <button
          className="btn"
          onClick={handleProceed}
          disabled={!canProceed()}
          style={{ marginTop: '16px' }}
        >
          Start Model Training
        </button>
      </div>
    </div>
  )
}

export default DataAnalysis