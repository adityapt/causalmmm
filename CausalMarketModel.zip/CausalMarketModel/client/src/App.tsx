import React, { useState } from 'react'
import DataUpload from './components/DataUpload'
import DataAnalysis from './components/DataAnalysis'
import ModelTraining from './components/ModelTraining'
import ModelResults from './components/ModelResults'

type Step = 'upload' | 'analysis' | 'training' | 'results'

interface AppState {
  step: Step
  fileData: any
  analysisData: any
  modelConfig: any
  modelId: string | null
  results: any
}

function App() {
  const [state, setState] = useState<AppState>({
    step: 'upload',
    fileData: null,
    analysisData: null,
    modelConfig: null,
    modelId: null,
    results: null
  })

  const updateState = (updates: Partial<AppState>) => {
    setState(prev => ({ ...prev, ...updates }))
  }

  const goToStep = (step: Step) => {
    setState(prev => ({ ...prev, step }))
  }

  return (
    <div className="container">
      <header style={{ textAlign: 'center', marginBottom: '40px' }}>
        <h1 style={{ 
          fontSize: '32px', 
          fontWeight: 'bold', 
          color: '#1f2937',
          marginBottom: '8px'
        }}>
          CausalMMM
        </h1>
        <p style={{ 
          fontSize: '16px', 
          color: '#6b7280',
          margin: '0'
        }}>
          Causal Marketing Mix Model with Graph Neural Networks & SHAP Analysis
        </p>
      </header>

      {/* Progress indicator */}
      <div className="card">
        <div className="grid grid-4" style={{ gridTemplateColumns: 'repeat(4, 1fr)', textAlign: 'center' }}>
          <div style={{ 
            color: state.step === 'upload' ? '#3b82f6' : '#9ca3af',
            fontWeight: state.step === 'upload' ? 'bold' : 'normal'
          }}>
            1. Upload Data
          </div>
          <div style={{ 
            color: state.step === 'analysis' ? '#3b82f6' : '#9ca3af',
            fontWeight: state.step === 'analysis' ? 'bold' : 'normal'
          }}>
            2. Analyze & Configure
          </div>
          <div style={{ 
            color: state.step === 'training' ? '#3b82f6' : '#9ca3af',
            fontWeight: state.step === 'training' ? 'bold' : 'normal'
          }}>
            3. Train Model
          </div>
          <div style={{ 
            color: state.step === 'results' ? '#3b82f6' : '#9ca3af',
            fontWeight: state.step === 'results' ? 'bold' : 'normal'
          }}>
            4. View Results
          </div>
        </div>
      </div>

      {/* Step content */}
      {state.step === 'upload' && (
        <DataUpload
          onFileUploaded={(fileData) => {
            updateState({ fileData, step: 'analysis' })
          }}
        />
      )}

      {state.step === 'analysis' && (
        <DataAnalysis
          fileData={state.fileData}
          onAnalysisComplete={(analysisData, modelConfig) => {
            updateState({ analysisData, modelConfig, step: 'training' })
          }}
          onBack={() => goToStep('upload')}
        />
      )}

      {state.step === 'training' && (
        <ModelTraining
          fileData={state.fileData}
          modelConfig={state.modelConfig}
          onTrainingComplete={(modelId, results) => {
            updateState({ modelId, results, step: 'results' })
          }}
          onBack={() => goToStep('analysis')}
        />
      )}

      {state.step === 'results' && (
        <ModelResults
          modelId={state.modelId}
          results={state.results}
          onStartNew={() => {
            setState({
              step: 'upload',
              fileData: null,
              analysisData: null,
              modelConfig: null,
              modelId: null,
              results: null
            })
          }}
        />
      )}
    </div>
  )
}

export default App